import { Controller, Get, Header, Param } from '@nestjs/common';
import { ApiTags, ApiOperation } from '@nestjs/swagger';
import { DashboardService } from '../services/dashboard.service';

@ApiTags('Dashboard')
@Controller('dashboard')
export class DashboardController {
  constructor(private dashboardService: DashboardService) {}

  @ApiOperation({ summary: `Get skippys and skipsters information` })
  @Get()
  @Header('Access-Control-Allow-Origin', '*')
  getDashboardInfo() {
    return this.dashboardService.getDashboardInfo();
  }

  @ApiOperation({ summary: `Get skippys and skipsters information` })
  @Get('missions/:skip')
  @Header('Access-Control-Allow-Origin', '*')
  getMissions(@Param('skip') skip: number) {
    return this.dashboardService.getMissions(skip);
  }
}
