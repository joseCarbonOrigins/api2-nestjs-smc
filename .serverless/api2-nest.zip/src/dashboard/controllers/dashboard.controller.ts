import { Controller, Post } from '@nestjs/common';

@Controller('dashboard')
export class DashboardController {}
