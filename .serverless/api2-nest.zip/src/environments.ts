export const environments = {
  dev: '.env',
  stag: '.stag.env',
  prod: '.prod.env',
};
