import { SentryInterceptor } from './sentry.interceptor';

describe('SentryInterceptor', () => {
  it('should be defined', () => {
    expect(new SentryInterceptor()).toBeDefined();
  });
});
