import { Prop, Schema, SchemaFactory, raw } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';
import { Skip } from './skip.schema';
import { Skipster } from './skipster.schema';

@Schema()
export class FakeMission extends Document {
  @Prop()
  mission_name: string;

  @Prop()
  mission_xp: number;

  @Prop()
  mission_coins: number;

  @Prop(
    raw({
      type: {
        type: String,
        enum: ['Point'],
        required: true,
      },
      coordinates: {
        type: [Number],
        required: true,
      },
    }),
  )
  start_point: Record<string, number[]>;

  @Prop(
    raw({
      type: {
        type: String,
        enum: ['Point'],
        required: true,
      },
      coordinates: {
        type: [Number],
        required: true,
      },
    }),
  )
  ending_point: Record<string, number[]>;

  @Prop()
  startTime: Date;

  @Prop()
  endTime: Date;

  @Prop()
  estimated_time: number;

  // maybe remove
  @Prop()
  start_address_name: string;

  @Prop({ required: true })
  ending_address_name: string;

  @Prop({ type: Types.ObjectId, ref: Skipster.name })
  skipster_id: Skipster | Types.ObjectId;

  @Prop({ type: Types.ObjectId, ref: Skip.name, required: true })
  skip_id: Skip | Types.ObjectId;

  @Prop({ required: true })
  mission_completed: boolean;

  @Prop({ required: true })
  previous_mission_completed: boolean;

  @Prop({ type: Types.ObjectId, ref: FakeMission.name })
  previous_mission_id: FakeMission | Types.ObjectId;
}

export const FakeMissionSchema = SchemaFactory.createForClass(FakeMission);
